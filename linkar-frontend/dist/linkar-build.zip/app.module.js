(function() {
  'use strict'

  angular.module('linkar', [
    'ngResource',
    'ngRoute'
  ]);

})();
